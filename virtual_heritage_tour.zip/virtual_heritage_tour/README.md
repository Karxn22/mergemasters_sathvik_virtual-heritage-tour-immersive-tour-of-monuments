# Virtual Heritage Tour

This project is a prototype for a virtual heritage tour application, created for a hackathon. It provides an immersive experience for exploring monuments with 360-degree views, dynamically generated interactive hotspots, and AI-powered audio narrations.

## Features

*   **360-Degree Exploration:** Explore monuments in a full 360-degree view.
*   **Dynamic Hotspots:** Hotspots are dynamically loaded and positioned based on real-time data fetched from the backend.
*   **AI-Powered Audio Narrations:** Listen to AI-generated audio narrations for each hotspot.
*   **Audio/Visual Info Overlays:** View textual information overlays for each hotspot.
*   **Dynamic Monument Data:** Monument data is fetched dynamically from external sources (e.g., Wikipedia), providing a vast and scalable tour experience.
*   **Web Dashboard:** A simple web-based dashboard to manage (view only) the tour data.

## Project Structure

The project is divided into four main components:

*   **`backend-api`**: A Node.js Express server that dynamically fetches monument data, orchestrates AI narration generation, and serves generated audio files.
*   **`ai-engine`**: A Python script that uses Google Text-to-Speech (gTTS) to generate audio narrations from text.
*   **`unity-app`**: A Unity application that provides the main user-facing experience, handling 360-degree navigation, dynamic hotspot rendering, and audio playback.
*   **`web-dashboard`**: A simple HTML/JavaScript dashboard to view the dynamically fetched tour data.

## Setup and Installation

### Backend API

1.  Navigate to the `backend-api` directory: `cd backend-api`
2.  Install the dependencies: `npm install`
3.  Start the server: `npm start`
    The server will run at `http://localhost:3000`.

### AI Engine

1.  Navigate to the `ai-engine` directory: `cd ai-engine`
2.  Install the Python dependencies: `pip install -r requirements.txt`

### Web Dashboard

1.  Open the `web-dashboard/index.html` file in a web browser.
2.  The dashboard will connect to the backend API to fetch and display the tour data.
    **Note:** This dashboard is currently for viewing data only, as monument data is now dynamically fetched.

### Unity App

1.  Open the `unity-app` project in the Unity Editor.
2.  Open the `MainScene.unity` scene from the `Assets/Scenes` directory.
3.  **Core GameObjects Setup:**
    *   Create empty GameObjects in your scene and attach the following scripts:
        *   `DataManager.cs` (Handles backend communication)
        *   `HotspotManager.cs` (Manages hotspot instantiation and clicks)
        *   `UIManager.cs` (Manages UI overlays)
        *   `AudioNarration.cs` (Manages audio playback)
        *   `TourManager.cs` (Orchestrates monument loading and scene flow)
4.  **`TourManager` Configuration:**
    *   On the `TourManager` GameObject, drag and drop the `PanoramaViewer` (main camera) into the `Panorama Viewer` field.
5.  **`HotspotManager` Configuration:**
    *   On the `HotspotManager` GameObject, drag and drop the `AudioNarration` GameObject into the `Audio Narration` field.
    *   Create a simple 3D object (e.g., a small `Sphere` from `GameObject -> 3D Object -> Sphere`). Adjust its size and appearance to your liking. This will serve as your hotspot prefab. Drag this GameObject from the Hierarchy into your `Assets` folder to create a Prefab. Then, drag this Prefab into the `Hotspot Prefab` field on the `HotspotManager` GameObject.
6.  **`UIManager` Configuration:**
    *   Create a UI Text element (`GameObject -> UI -> Text - TextMeshPro` is recommended, import TMP Essentials). This will be your info overlay.
    *   On the `UIManager` GameObject, drag this UI Text element into the `Info Text` field. Initially, set the Text GameObject to inactive in the Inspector (`Inspector -> checkbox next to its name`).
7.  **`AudioNarration` Configuration:**
    *   Ensure the `AudioNarration` GameObject has an `AudioSource` component attached (`Add Component -> Audio Source`).
8.  **360-Degree View Setup:**
    *   Create a large sphere in the scene (`GameObject -> 3D Object -> Sphere`). Scale it to be very large (e.g., `Scale: 100, 100, 100`) and position it at `(0, 0, 0)`.
    *   Create a new Material (`Assets -> Create -> Material`).
    *   Assign a 360-degree panorama image to this material's albedo (main texture). You will need to provide your own 360-degree images (e.g., `placeholder.jpg` for testing). Place them in a `Resources` folder inside `Assets`. The `panoramaImage` field in the backend data currently uses `placeholder.jpg`. You will need to manage loading the correct image based on the monument.
    *   For the 360-degree effect, you need to display the panorama *from the inside* of the sphere. You can either:
        *   Invert the sphere's normals in a 3D modeling software and re-import.
        *   Use a custom shader that renders the backfaces.
        *   A simple hack for demonstration: Scale the sphere uniformly with negative values (e.g., `-100, -100, -100`) after applying the material, or wrap it using a custom sphere mesh where normals are inverted.
    *   Apply this material to the large sphere.
9.  **Camera Setup:**
    *   Ensure your `Main Camera` is positioned at `(0, 0, 0)`.
    *   Attach the `PanoramaViewer.cs` script to the `Main Camera`.

## Deployment (Making your project public)

To share your project, you'll need to deploy its components.

1.  **Deploy Backend API with `ngrok`**:
    *   Download `ngrok` from [ngrok.com/download](https://ngrok.com/download).
    *   Start your backend API locally (`cd backend-api && npm start`).
    *   In a new terminal, run `ngrok http 3000`.
    *   `ngrok` will provide a public URL (e.g., `https://xxxx.ngrok.io`). **Copy this URL.**
2.  **Update Unity App's Backend URL**:
    *   In Unity, open `DataManager.cs` and replace `http://localhost:3000` with your `ngrok` URL.
3.  **Build Unity App for WebGL**:
    *   In Unity Editor, go to `File > Build Settings`, select `WebGL`, and click `Build`.
4.  **Host WebGL Build**:
    *   Drag and drop the entire WebGL build folder onto [app.netlify.com/drop](https://app.netlify.com/drop). Netlify will host it and give you a public link.
5.  **Host Web Dashboard (Optional)**:
    *   If you want to host the `web-dashboard` publicly, update the `fetch` URLs in `web-dashboard/index.html` to point to your `ngrok` URL, then drag and drop its folder onto Netlify Drop.

## How to Use

1.  Ensure your backend API is running (either locally or via `ngrok`).
2.  Open the Unity app (either in Editor or the WebGL build).
3.  Use the mouse to look around the 360-degree view.
4.  Navigate between monuments using the **Left Arrow** and **Right Arrow** keys.
5.  Click on the dynamically spawned hotspots to see information and hear the narration.
6.  (If deployed) Share your Netlify link for the WebGL build with others!