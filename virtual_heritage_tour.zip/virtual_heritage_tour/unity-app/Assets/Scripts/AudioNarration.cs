using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class AudioNarration : MonoBehaviour
{
    private AudioSource audioSource;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
    }

    public void PlayNarration(string narrationText, string filename)
    {
        DataManager.Instance.GetNarration(narrationText, filename, (narrationResponse) => {
            DataManager.Instance.GetAudioClip(narrationResponse.path, (audioClip) => {
                if (audioClip != null)
                {
                    audioSource.PlayOneShot(audioClip);
                }
            });
        });
    }
}