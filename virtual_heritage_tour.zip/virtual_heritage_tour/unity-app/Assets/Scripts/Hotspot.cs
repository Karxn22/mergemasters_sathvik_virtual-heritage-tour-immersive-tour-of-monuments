using UnityEngine;

public class Hotspot : MonoBehaviour
{
    public string hotspotId;
    public string narration;
    public string info;

    void OnMouseDown()
    {
        HotspotManager.Instance.OnHotspotClicked(this);
    }
}
