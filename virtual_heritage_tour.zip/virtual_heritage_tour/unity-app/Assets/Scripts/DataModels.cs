using System;
using System.Collections.Generic;

[Serializable]
public class Monument
{
    public string id;
    public string name;
    public string panoramaImage;
    public List<HotspotData> hotspots;
}

[Serializable]
public class HotspotData
{
    public string id;
    public Position position;
    public string narration;
    public string info;
}

[Serializable]
public class Position
{
    public float x;
    public float y;
    public float z;
}

[Serializable]
public class NarrationResponse
{
    public string message;
    public string path;
}
