using UnityEngine;
using System.Collections.Generic;

public class HotspotManager : MonoBehaviour
{
    public static HotspotManager Instance { get; private set; }

    public AudioNarration audioNarration; // Assign this in the Unity Editor
    public GameObject hotspotPrefab; // Assign a 3D prefab for hotspots in the Unity Editor

    private List<GameObject> activeHotspots = new List<GameObject>();

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void LoadHotspotsForMonument(Monument monument)
    {
        // Clear existing hotspots
        foreach (GameObject go in activeHotspots)
        {
            Destroy(go);
        }
        activeHotspots.Clear();

        // Instantiate new hotspots
        foreach (HotspotData hotspotData in monument.hotspots)
        {
            GameObject hotspotGO = Instantiate(hotspotPrefab, transform);
            hotspotGO.transform.localPosition = new Vector3(hotspotData.position.x, hotspotData.position.y, hotspotData.position.z);

            Hotspot hotspotComponent = hotspotGO.GetComponent<Hotspot>();
            if (hotspotComponent != null)
            {
                hotspotComponent.hotspotId = hotspotData.id;
                hotspotComponent.narration = hotspotData.narration;
                hotspotComponent.info = hotspotData.info;
            }
            activeHotspots.Add(hotspotGO);
        }
    }

    public void OnHotspotClicked(Hotspot hotspot)
    {
        // Show info overlay
        UIManager.Instance.ShowInfo(hotspot.info);

        // Play narration
        if (audioNarration != null)
        {
            string filename = $"{hotspot.hotspotId}_{System.DateTime.Now.Ticks}";
            audioNarration.PlayNarration(hotspot.narration, filename);
        }
    }
}