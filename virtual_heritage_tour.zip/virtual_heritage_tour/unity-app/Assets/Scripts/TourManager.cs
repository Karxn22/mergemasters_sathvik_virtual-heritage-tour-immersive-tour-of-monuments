using UnityEngine;
using System.Collections.Generic;

public class TourManager : MonoBehaviour
{
    public static TourManager Instance { get; private set; }

    public PanoramaViewer panoramaViewer; // Assign in Inspector

    private List<Monument> allMonuments;
    private int currentMonumentIndex = 0;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        // Ensure DataManager and HotspotManager are in the scene and initialized
        if (DataManager.Instance == null)
        {
            Debug.LogError("DataManager not found in scene!");
            return;
        }
        if (HotspotManager.Instance == null)
        {
            Debug.LogError("HotspotManager not found in scene!");
            return;
        }
        if (UIManager.Instance == null)
        {
            Debug.LogError("UIManager not found in scene!");
            return;
        }

        UIManager.Instance.HideInfo(); // Hide info panel at start

        // Fetch all monuments from the backend
        DataManager.Instance.GetMonuments((monuments) => {
            allMonuments = monuments;
            if (allMonuments != null && allMonuments.Count > 0)
            {
                LoadMonument(currentMonumentIndex);
            }
            else
            {
                Debug.LogError("No monuments received from backend.");
            }
        });
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            NextMonument();
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            PreviousMonument();
        }
    }

    public void LoadMonument(int index)
    {
        if (allMonuments == null || index < 0 || index >= allMonuments.Count)
        {
            Debug.LogError("Invalid monument index.");
            return;
        }

        currentMonumentIndex = index;
        Monument selectedMonument = allMonuments[currentMonumentIndex];
        Debug.Log($"Loading monument: {selectedMonument.name}");

        // Load hotspots for the selected monument
        HotspotManager.Instance.LoadHotspotsForMonument(selectedMonument);

        // Load panorama image (this part will be enhanced later)
        // For now, it's assumed the PanoramaViewer is ready to accept a texture or material.
        // We'll update PanoramaViewer to dynamically load images in the next step.
        // panoramaViewer.LoadPanorama(selectedMonument.panoramaImage); 
    }

    public void NextMonument()
    {
        currentMonumentIndex = (currentMonumentIndex + 1) % allMonuments.Count;
        LoadMonument(currentMonumentIndex);
    }

    public void PreviousMonument()
    {
        currentMonumentIndex = (currentMonumentIndex - 1 + allMonuments.Count) % allMonuments.Count;
        LoadMonument(currentMonumentIndex);
    }
}
