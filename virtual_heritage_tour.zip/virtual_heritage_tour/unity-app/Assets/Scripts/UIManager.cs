using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    public Text infoText; // Assign this in the Unity Editor

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void ShowInfo(string message)
    {
        if (infoText != null)
        {
            infoText.text = message;
            infoText.gameObject.SetActive(true);
        }
    }

    public void HideInfo()
    {
        if (infoText != null)
        {
            infoText.gameObject.SetActive(false);
        }
    }
}
