using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;

public class DataManager : MonoBehaviour
{
    public static DataManager Instance { get; private set; }

    private string backendUrl = "http://localhost:3000";

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void GetMonuments(System.Action<List<Monument>> callback)
    {
        StartCoroutine(GetRequest("/monuments", (json) => {
            List<Monument> monuments = JsonUtility.FromJson<List<Monument>>("{\"monuments\":