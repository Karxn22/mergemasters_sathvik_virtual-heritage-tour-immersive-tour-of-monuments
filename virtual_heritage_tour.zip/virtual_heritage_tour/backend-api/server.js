const express = require('express');
const cors = require('cors');
const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');
const { execFile } = require('child_process');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.send('Welcome to the Virtual Heritage Tour API! Try accessing /monuments.');
});

app.get('/monuments', async (req, res) => {
    try {
        const url = 'https://en.wikipedia.org/wiki/List_of_Monuments_of_National_Importance_in_Delhi';
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const monuments = [];

        $('table.wikitable tbody tr').each((i, elem) => {
            if (i === 0) return; // Skip header row

            const name = $(elem).find('td').eq(1).text().trim();
            const description = $(elem).find('td').eq(3).text().trim();
            
            if (name) {
                monuments.push({
                    id: name.toLowerCase().replace(/\s/g, '-'),
                    name: name,
                    panoramaImage: 'placeholder.jpg',
                    hotspots: [
                        {
                            id: 'hotspot-1',
                            position: { x: 0, y: 0, z: 5 },
                            narration: `This is ${name}. ${description}`,
                            info: description
                        }
                    ]
                });
            }
        });

        res.send(monuments);
    } catch (error) {
        console.error(error);
        res.status(500).send('Error fetching monument data.');
    }
});

app.post('/narrate', (req, res) => {
    const { text, filename } = req.body;
    if (!text || !filename) {
        return res.status(400).send('Missing text or filename');
    }

    const pythonScriptPath = path.join(__dirname, '..', 'ai-engine', 'narration.py');
    const outputFilePath = path.join(__dirname, 'public', 'audio', `${filename}.mp3`);

    execFile('python', [pythonScriptPath, text, outputFilePath], (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing python script: ${error}`);
            return res.status(500).send('Failed to generate narration');
        }
        console.log(`Python script stdout: ${stdout}`);
        console.error(`Python script stderr: ${stderr}`);
        res.send({ message: 'Narration generated successfully', path: `/audio/${filename}.mp3` });
    });
});

app.post('/monuments', (req, res) => {
    const updatedMonuments = req.body;
    console.log('Received updated monuments data:');
    console.log(JSON.stringify(updatedMonuments, null, 2));
    // In a real application, you would save this data to a file or database.
    // For now, we'll just confirm receipt.
    res.status(200).send({ message: 'Data received successfully.' });
});


app.listen(port, () => {
    console.log(`Backend server listening at http://localhost:${port}`);
});