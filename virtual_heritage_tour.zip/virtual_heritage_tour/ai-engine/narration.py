from gtts import gTTS
import sys

def generate_narration(text, output_path):
    try:
        tts = gTTS(text=text, lang='en', slow=False)
        tts.save(output_path)
        print(f"Successfully generated narration audio at {output_path}")
    except Exception as e:
        print(f"Error generating narration: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python narration.py <text_to_narrate> <output_file_path>")
        sys.exit(1)
    
    text_to_narrate = sys.argv[1]
    output_file_path = sys.argv[2]
    
    generate_narration(text_to_narrate, output_file_path)
